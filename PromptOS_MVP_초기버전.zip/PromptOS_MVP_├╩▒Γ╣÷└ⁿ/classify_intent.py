def classify_intent(utterance: str) -> dict:
    """
    사용자 발화를 기반으로 intent, sub_intent, domain 정보를 추출합니다.
    항상 dict 형식으로 결과를 반환합니다.
    """
    utterance = utterance.lower().strip()

    result = {
        "intent": "unknown",
        "sub_intent": None,
        "domain": None,
        "policy": None  # 향후 확장 가능
    }

    if not utterance:
        return result

    # 제안서 관련 intent
    if "제안서" in utterance or "proposal" in utterance:
        result["intent"] = "proposal"

        if any(x in utterance for x in ["ai", "인공지능", "gpt", "생성형"]):
            result["sub_intent"] = "ai"
        elif any(x in utterance for x in ["스마트시티", "smart city"]):
            result["sub_intent"] = "smartcity"
        elif any(x in utterance for x in ["환경", "기후", "탄소", "에너지"]):
            result["sub_intent"] = "climate"

        if any(x in utterance for x in ["정부", "공공", "gov", "정부지원"]):
            result["domain"] = "government"
        elif any(x in utterance for x in ["기업", "민간", "b2b"]):
            result["domain"] = "private"

    # 요약
    elif any(x in utterance for x in ["요약", "정리", "한 문장"]):
        result["intent"] = "summary"

    # 자기소개
    elif any(x in utterance for x in ["자기소개", "자소서", "소개글"]):
        result["intent"] = "self_intro"

    # 고객 응대
    elif any(x in utterance for x in ["답장", "응대", "불만", "사과", "클레임"]):
        result["intent"] = "customer_reply"

    # 코드 실행
    elif any(x in utterance for x in ["코드", "함수", "스크립트"]):
        result["intent"] = "code_run"

    return result

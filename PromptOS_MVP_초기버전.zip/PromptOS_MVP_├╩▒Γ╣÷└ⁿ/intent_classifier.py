import re

def classify_intent(utterance: str) -> dict:
    utterance = utterance.lower().strip()

    result = {
        "intent": "unknown",
        "sub_intent": None,
        "domain": None,
        "audience": None
    }

    rules = [
        {
            "intent": "proposal",
            "sub_intent": "ai",
            "domain": "ai",
            "patterns": ["ai", "인공지능"],
            "audience_map": {
                "government": ["정부", "공공", "gov", "정부기관"],
                "private": ["기업", "회사", "b2b", "고객사"]
            },
        },
        {
            "intent": "proposal",
            "sub_intent": "climate",
            "domain": "climate",
            "patterns": ["환경", "기후", "탄소", "net zero"],
        },
        {
            "intent": "self_intro",
            "patterns": ["자기소개", "자소서", "이력서", "소개글"],
        },
        {
            "intent": "summary",
            "patterns": ["요약", "정리", "한 문장", "핵심"],
        },
        {
            "intent": "customer_reply",
            "patterns": ["답장", "응대", "클레임", "사과문", "고객센터"],
        },
        {
            "intent": "code_run",
            "patterns": ["코드", "함수", "스크립트", "파이썬", "코딩"],
        }
    ]

    for rule in rules:
        for keyword in rule.get("patterns", []):
            if keyword in utterance:
                result["intent"] = rule["intent"]
                result["sub_intent"] = rule.get("sub_intent")
                result["domain"] = rule.get("domain")

                if "audience_map" in rule:
                    for aud, keywords in rule["audience_map"].items():
                        if any(k in utterance for k in keywords):
                            result["audience"] = aud
                            break

                return result

    return result

import streamlit as st
from intent_classifier import classify_intent
from prompt_generator import extract_conditions, generate_prompt
from prompt_builder import get_template, extract_placeholders, prompt_missing_values, fill_template

def main():
    st.set_page_config(page_title="PromptOS - 프롬프트 생성기", layout="wide")
    st.title("💡 PromptOS 자동 생성기")
    st.write("자연어 한 줄 → 고품질 프롬프트 완성")

    # 사용자 입력
    utterance = st.text_input("✍️ 어떤 작업을 원하시나요?", placeholder="예: 광고 스크립트 작성")

    if st.button("프롬프트 생성하기"):
        if not utterance.strip():
            st.warning("⚠️ 작업 내용을 입력해주세요.")
            return

        # 1. 의도 분류
        parsed = classify_intent(utterance)
        intent = parsed.get("intent") or "unknown"
        sub_intent = parsed.get("sub_intent")
        domain = parsed.get("domain")

        if intent == "unknown":
            st.error("❗ 입력 내용을 이해하지 못했습니다. 다시 입력해주세요.")
            return
        st.write(f"📌 **Intent:** {intent} / **Sub:** {sub_intent} / **Domain:** {domain}")

        # 2. 조건 추출
        conditions = extract_conditions(utterance)
        tone = conditions.get("tone") or "중립적"
        tense = conditions.get("tense") or "현재시제"
        audience = conditions.get("audience") or "정부 관계자"
        st.write(f"🔍 **Tone:** {tone} / **Tense:** {tense} / **Audience:** {audience}")

        # 3. 템플릿 키 조합
        template_key = intent
        if sub_intent:
            template_key += f"_{sub_intent}"
        if domain:
            template_key += f"_{domain}"
        st.write(f"📂 **템플릿 키:** {template_key}")

        # 4. 템플릿 불러오기
        template_text = get_template(template_key)
        if not template_text:
            st.error(f"❗ '{template_key}'에 해당하는 템플릿 파일이 존재하지 않습니다.")
            return

        # 5. 누락된 값 입력
        placeholders = extract_placeholders(template_text)
        values = {
            "user_utterance": utterance,
            "intent": intent,
            "sub_intent": sub_intent,
            "domain": domain,
            "tone": tone,
            "tense": tense,
            "audience": audience,
        }

        missing_keys = [ph for ph in placeholders if ph not in values or not values[ph]]
        if missing_keys:
            st.info(f"⚠️ 누락된 값: {', '.join(missing_keys)}")
            user_inputs = prompt_missing_values(missing_keys)
            values.update(user_inputs)

        # 6. 프롬프트 완성
        final_prompt = fill_template(template_text, values)

        # 7. 결과 출력
        st.subheader("🧠 [생성된 프롬프트]")
        st.code(final_prompt, language="markdown")

if __name__ == "__main__":
    main()

# prompt_builder.py

import os
import re

TEMPLATE_DIR = "templates"

def extract_placeholders(template: str) -> list:
    return re.findall(r"{(.*?)}", template)

def prompt_missing_values(placeholders: list) -> dict:
    values = {}
    for ph in placeholders:
        user_input = input(f"💬 '{ph}' 값을 입력해주세요: ").strip()
        values[ph] = user_input
    return values

def fill_template(template: str, values: dict) -> str:
    try:
        return template.format(**values)
    except KeyError as e:
        missing_key = e.args[0]
        return f"⚠️ 누락된 값이 있습니다: {missing_key}"

def get_template(template_key: str, base_dir="templates", fallback="unknown") -> str:
    """
    템플릿 키 기반으로 다단계 탐색
    예: "proposal_ai_government" → templates/proposal/ai/government.txt
        "self_intro" → templates/self_intro.txt
    """
    # 1. 직접 매핑 시도 (templates/template_key.txt)
    direct_path = os.path.join(base_dir, f"{template_key}.txt")
    if os.path.isfile(direct_path):
        with open(direct_path, encoding="utf-8") as f:
            return f.read()

    # 2. 하위 폴더 매핑 시도 (templates/proposal/ai/government.txt 등)
    nested_path = os.path.join(base_dir, *template_key.split("_")) + ".txt"
    if os.path.isfile(nested_path):
        with open(nested_path, encoding="utf-8") as f:
            return f.read()

    # 3. fallback 템플릿 사용
    fallback_path = os.path.join(base_dir, f"{fallback}.txt")
    if os.path.isfile(fallback_path):
        with open(fallback_path, encoding="utf-8") as f:
            return f.read()

    print(f"❗ [템플릿 없음] '{template_key}' 관련 템플릿을 찾지 못했습니다.")
    return ""

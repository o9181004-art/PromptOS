# PromptOS MVP

## ✅ Description
Local MVP for generating prompts based on user intent and context.

## 🛠 How to Use

1. Install dependencies:

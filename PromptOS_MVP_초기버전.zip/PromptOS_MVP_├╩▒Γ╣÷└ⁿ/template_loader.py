import os

def get_template(template_key: str, base_dir="templates", fallback="unknown") -> str:
    """
    템플릿 키에 따라 파일을 찾습니다. 중첩된 폴더가 있을 경우를 지원.
    예외적으로 self_intro 같은 키는 하위 폴더가 아님을 인지하여 처리.
    """
    # 직접 경로 확인
    direct_path = os.path.join(base_dir, f"{template_key}.txt")
    if os.path.isfile(direct_path):
        with open(direct_path, "r", encoding="utf-8") as f:
            return f.read()

    # 계층적 경로 시도 (proposal_ai_ai → templates/proposal/ai/ai.txt)
    relative_path = template_key.replace("_", os.sep) + ".txt"
    nested_path = os.path.join(base_dir, relative_path)
    if os.path.isfile(nested_path):
        with open(nested_path, "r", encoding="utf-8") as f:
            return f.read()

    # fallback
    fallback_path = os.path.join(base_dir, f"{fallback}.txt")
    if os.path.isfile(fallback_path):
        with open(fallback_path, "r", encoding="utf-8") as f:
            return f.read()

    return ""

import re

def extract_conditions(utterance: str) -> dict:
    """
    사용자 발화에서 tone, tense, audience를 단순 규칙 기반으로 추출합니다.
    추출 실패 시 기본값 제공
    """
    utterance_lower = utterance.lower()

    # tone
    if any(word in utterance_lower for word in ["정중", "공손", "丁寧", "polite"]):
        tone = "polite"
    elif any(word in utterance_lower for word in ["간결", "짧게", "간단"]):
        tone = "concise"
    elif any(word in utterance_lower for word in ["격식", "포멀", "formal"]):
        tone = "formal"
    else:
        tone = "neutral"

    # tense
    if "계획" in utterance or "예정" in utterance or re.search(r"\b(will|going to)\b", utterance_lower):
        tense = "future"
    elif any(past in utterance for past in ["했", "하였다", "완료", "진행했", "마쳤", "적용했"]) or re.search(r"\b(did|was|had)\b", utterance_lower):
        tense = "past"
    else:
        tense = "present"

    # audience
    if any(word in utterance_lower for word in ["고객", "user", "consumer"]):
        audience = "customer"
    elif any(word in utterance_lower for word in ["임원", "ceo", "executive"]):
        audience = "executive"
    elif any(word in utterance_lower for word in ["학생", "초등", "중학생"]):
        audience = "student"
    elif any(word in utterance_lower for word in ["정부", "행정", "공공기관"]):
        audience = "정부 관계자"
    else:
        audience = "general"

    return {
        "tone": tone,
        "tense": tense,
        "audience": audience
    }

def generate_prompt(template: str, values: dict) -> str:
    """
    (선택사항) 추후 프롬프트 직접 생성기로 고도화할 경우 사용
    현재는 템플릿 기반 구조 유지
    """
    return template.format(**values)

import streamlit as st
from intent_classifier import classify_intent
from prompt_generator import extract_conditions
from prompt_builder import get_template, extract_placeholders, prompt_missing_values, fill_template

st.set_page_config(page_title="PromptOS 자연어 생성기")

st.markdown("## 🧠 PromptOS 자연어 생성기")
st.markdown("발화 내용을 입력하면 자동으로 템플릿을 선택하고 조건을 추출합니다.")

utterance = st.text_input("💬 자연어로 입력해주세요", placeholder="예: ai 기반 제안서를 정부에 제출할거야")

if st.button("✍️ 프롬프트 생성") and utterance:
    # 1. Intent 분류
    parsed = classify_intent(utterance)

    # ✅ 방어 코드 추가: dict인지 확인
    if not isinstance(parsed, dict):
        st.error("❗ classify_intent() 함수가 올바른 딕셔너리를 반환하지 않았습니다.")
        st.stop()

    intent = parsed.get("intent") or "unknown"
    sub_intent = parsed.get("sub_intent")
    domain = parsed.get("domain")

    # 2. 조건 추출
    conditions = extract_conditions(utterance)
    tone = conditions.get("tone") or "중립적"
    tense = conditions.get("tense") or "현재시제"
    audience = conditions.get("audience") or "정부 관계자"

    # 3. 템플릿 키 조합
    template_key = intent
    if sub_intent:
        template_key += f"_{sub_intent}"
    if domain:
        template_key += f"_{domain}"
    st.markdown(f"🔑 **분류 결과:** `{template_key}`")

    # 4. 템플릿 로드
    template_text = get_template(template_key)
    if not template_text:
        st.error("❌ 해당 intent에 맞는 템플릿이 없습니다.")
    else:
        # 5. Placeholder 추출 및 누락값 보완
        placeholders = extract_placeholders(template_text)
        values = {
            "user_utterance": utterance,
            "intent": intent,
            "sub_intent": sub_intent,
            "domain": domain,
            "tone": tone,
            "tense": tense,
            "audience": audience,
        }

        # 누락된 항목만 추가 입력받기
        missing_keys = [k for k in placeholders if not values.get(k)]
        if missing_keys:
            st.warning("⚠️ 누락된 값을 입력해주세요.")
            for key in missing_keys:
                values[key] = st.text_input(f"🔧 '{key}' 값을 입력해주세요")

        # 6. 모든 값이 입력되었을 때 결과 출력
        if all(values.get(k) for k in placeholders):
            final_prompt = fill_template(template_text, values)
            st.success("✅ 프롬프트가 생성되었습니다.")
            st.code(final_prompt, language="text")
        else:
            st.info("💡 모든 필수 값이 입력되어야 프롬프트가 완성됩니다.")
